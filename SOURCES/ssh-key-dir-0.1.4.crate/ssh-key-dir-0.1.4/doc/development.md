# Development

## Release process

Releases can be performed by [creating a new release ticket][new-release-ticket] and following the steps in the checklist there.

[new-release-ticket]: https://github.com/coreos/ssh-key-dir/issues/new?labels=release&template=release-checklist.md
